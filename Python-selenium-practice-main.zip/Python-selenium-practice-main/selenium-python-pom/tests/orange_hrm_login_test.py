
from base_test import BaseTest


class TestOrangeHRMLogin(BaseTest):
    def test_login(self):
        print("Login successfully")



