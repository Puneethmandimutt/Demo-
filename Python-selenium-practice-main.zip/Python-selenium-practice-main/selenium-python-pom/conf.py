
Credential = {
    "Url" : "https://opensource-demo.orangehrmlive.com/",
    "User" : "admin",
    "Password": "admin123",
    "UserName" : "Paul Collings"
}